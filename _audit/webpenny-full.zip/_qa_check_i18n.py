import re
from pathlib import Path

t = Path(r"C:\WebPenny\src\Pennymatch.Web\Localization\SiteCatalog.cs").read_text(encoding="utf-8")
parts = t.split("BuildEn()")
es_part = parts[0].split("BuildEs()")[1]
en_part = parts[1]
es_keys = re.findall(r'\["([^"]+)"\]', es_part)
en_keys = re.findall(r'\["([^"]+)"\]', en_part)
print("ES", len(es_keys), "EN", len(en_keys))
print("only ES", sorted(set(es_keys) - set(en_keys)))
print("only EN", sorted(set(en_keys) - set(es_keys)))


def val(part: str, key: str) -> str:
    m = re.search(rf'\["{re.escape(key)}"\]\s*=\s*((?:@"[^"]*"|"[^"]*"\s*\+?\s*)+);', part)
    if not m:
        # multiline string concat with newlines
        m = re.search(
            rf'\["{re.escape(key)}"\]\s*=\s*((?:@"[^"]*"|"[^"]*"|\s*\+\s*)+);',
            part,
            re.S,
        )
    if not m:
        return ""
    return "".join(re.findall(r'"([^"]*)"', m.group(1)))


for k in [
    "Home.Title",
    "Home.Description",
    "Home.OgDescription",
    "Docs.Title",
    "Docs.Description",
    "Blog.Title",
    "Blog.Description",
]:
    ev, nv = val(es_part, k), val(en_part, k)
    print(f"ES {k} {len(ev)} | {ev}")
    print(f"EN {k} {len(nv)} | {nv}")
